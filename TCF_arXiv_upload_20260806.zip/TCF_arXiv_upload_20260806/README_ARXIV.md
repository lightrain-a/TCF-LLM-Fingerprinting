# TCF arXiv Public Preprint Working Copy

## Directory

```text
/home/wyt/code/VLMFingerprint/paper/LLM/TCF_arXiv_20260806
```

## Entry files

- `main.tex`: public arXiv/preprint entry.
- `authors_arxiv.tex`: author names, affiliations, and email addresses.
- `affiliation_marks.tex`: first-page placement of the HUST, Alibaba Group, and Microsoft logo files.
- `logos/`: page-1 logo assets and the HUST vector-logo license notice.
- `main.pdf`: latest compiled public preprint.

## Manuscript-content policy

This directory is a self-contained public-preprint branch derived from the current NDSS manuscript. Its section files are copied locally under `sec/`, so arXiv-specific presentation changes do not modify the conference submission tree.

The public entry differs from the conference entry in the following controlled ways:

1. anonymous authors are replaced by public author metadata;
2. the conference publication block and Ethics Considerations section are removed;
3. the first-page affiliation strip uses the standalone HUST seal (the adjacent Chinese/English wordmark is clipped), followed by the Alibaba Group and Microsoft marks;
4. the abstract, anonymous repository link, core method contract, and all experimental/theory Takeaways use restrained colored callout boxes;
5. every Takeaway is a concise conclusion-only statement rather than a repetition of table or figure values;
6. the appendix switches to a single-column layout with a roadmap and wider figures/tables;
7. the appendix includes cross-model SCM validation, complete theory details, exact clean/fingerprint query templates, the parser/scoring contract, and representative Raw-GCG/NC-S4/NC-S8 prompt examples;
8. the extended arXiv appendix restores the adaptive SCM checkpoint rule, end-to-end construction and online-verification records, registry schema, reproducibility checklist, baseline artifacts, naturalness metrics and variants, embedding diagnostics, a distillation checkpoint sweep, and an artifact map;
9. the public-support-material model-wise results are restored as a family summary, an exception table, and four full per-suspect matrices for Qwen3-1.7B Instruct, Qwen3-1.7B Base, Llama3-8B Base Direct, and Mistral-7B-v0.3;
10. code and reproducibility material point to the public GitHub repository `https://github.com/Underflow-1/TCF-LLM-Fingerprinting`. 

## Build

```bash
cd /home/wyt/code/VLMFingerprint/paper/LLM/TCF_arXiv_20260806
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error main.tex
```

## Current build result

```text
PDF: main.pdf
Pages: 36
Paper size: US Letter
Fatal errors: 0
Undefined references/citations: 0
Logo-related overfull boxes: 0
```

## Logo references and approval

The page-1 marks use reusable image/vector assets rather than hand-drawn approximations:

- HUST vector mark: `https://github.com/MatNoble/hust-cnlogo` (`images/pdf/hustcwhole.pdf`, cropped at inclusion time to retain only the seal; LPPL 1.3c; license included in `logos/HUST_CNLOGO_LICENSE.txt`)
- Alibaba Group official News and Media logo resources: `https://home.alibabagroup.com/en-US/resource-logos`
- Microsoft official web logo asset: `https://uhf.microsoft.com/images/microsoft/RE1Mu3b.png`

Before public upload, the Alibaba Group and Microsoft coauthors should confirm that this academic-paper use is approved under their internal brand/trademark process. The public Alibaba media library limits its downloadable files to specified editorial use, and Microsoft's public trademark guidance states that use of the corporate logo may require authorization.

## Before arXiv upload

Run `./package_arxiv.sh` to create a self-contained arXiv source package containing the chapter files, figures, bibliography, class files, official-source logos, and compiled PDF.
