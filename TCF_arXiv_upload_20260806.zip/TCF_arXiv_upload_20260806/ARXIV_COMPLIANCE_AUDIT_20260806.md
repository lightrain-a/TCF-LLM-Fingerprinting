# arXiv 格式与上传规范核对（2026-08-06）

## 官方结论

arXiv **没有要求使用统一论文模板或指定 LaTeX class**。IEEEtran、article、ACM 等均可使用，但最终稿必须满足 arXiv 的通用格式与源码要求。

## 当前公开版核对

| 项目 | arXiv 官方要求 | 当前状态 | 结论 |
|---|---|---|---|
| 固定模板 | 无统一模板要求 | 使用 IEEEtran conference 作为公开版排版基础 | PASS |
| 作者信息 | 不接受匿名稿；作者与单位必须完整准确 | 13 位作者、4 个单位和邮箱已列出 | PASS |
| 共同贡献 | PDF 中可说明；Authors 元数据不加入角色文字 | Yutong Wu 与 Xiaofan Bai 已以 `*` 标记，并注明 Equal contribution | PASS |
| 正文字号 | 10--14 pt | 主体 10 pt；正文/附录仍含局部 `small/scriptsize/tiny` | ACTION |
| 行距 | 单倍行距 | IEEEtran 单倍行距 | PASS |
| 页面边距 | 至少 1 inch | 已加入 `geometry[margin=1in]`；正常文本边距约 1 inch | PASS WITH LAYOUT WARNINGS |
| 行号 | 不允许 | 无行号 | PASS |
| 遮挡正文的水印 | 不允许 | 无水印；只有 `Public preprint` 通知 | PASS |
| 广告 | 不允许 | 三个机构标识仅作为作者单位标识，尺寸较小 | MANUAL/BRAND APPROVAL |
| 高亮、边注、审稿备注 | 不允许 | 未发现活动高亮、边注或 referee remarks | PASS |
| 参考文献 | 必须完整 | 引用可解析，参考文献完整 | PASS |
| 代码/数据链接 | 链接必须可公开访问 | 匿名代码链接由浏览器访问可用 | PASS / FINAL BROWSER CHECK |
| 摘要元数据 | 不超过 1920 ASCII 字符 | 论文摘要约 2226 字符；已另建 1193 字符元数据摘要 | PASS VIA `ARXIV_METADATA.txt` |
| TeX 源码 | TeX 稿应上传源码而非仅上传由 TeX 生成的 PDF | 当前工作版是 LaTeX | PASS |
| 自包含上传包 | 所有源文件、图和类文件必须在上传包内 | 当前 `main.tex` 仍引用 `../NDSS27_LLM_IP_Protection_20260731` | ACTION |
| `.bib/.bbl` | 使用 BibTeX/Biber 时应包含 `.bib` 或 `.bbl` | 当前通过邻接目录读取 | ACTION：自包含打包时复制到根目录 |
| 图格式 | PDFLaTeX 使用 PDF/JPG/PNG | 当前活动图符合 | PASS |
| 文件名 | 仅使用字母、数字、`_+-.,=`；大小写必须精确 | 当前主要文件名符合 | PASS |
| 上传大小 | 通常不超过 50 MB | 当前工作目录约 1.4 MB；自包含包预计仍远低于限制 | PASS |
| PDF 检查 | 必须人工预览 arXiv 编译结果 | 本地编译成功；正式上传时仍须检查 arXiv Preview | PENDING |

## 当前需要处理的上传前动作

1. 建立完全自包含的 arXiv source package，移除所有 `../` 路径。
2. 将实际使用的 `sec/`、图件、`references.bib`、`main.bbl` 和 `IEEEtran.cls` 复制到包内。
3. 处理 4 个明显的公式 Overfull，以及附录表格的轻微 Overfull。
4. 审查并处理 16 处局部小字号命令，避免低于 arXiv 的 10 pt 口径。
5. 在 arXiv 网页 Authors 字段只填姓名和单位；共同贡献写入 PDF，并在 Comments 中注明。
6. 使用 `ARXIV_METADATA.txt` 中的短摘要，而不是直接复制论文长摘要。
7. 上传后逐页核对 arXiv 自动编译 PDF、作者元数据、摘要和代码链接。

## 当前编译状态

```text
PDF: main.pdf
Pages: 36
Paper: US Letter
Base font: 10 pt
Fatal errors: 0
Undefined citations/references: 0
Significant formula Overfull warnings: 4
Appendix table minor Overfull warnings: 4
```
